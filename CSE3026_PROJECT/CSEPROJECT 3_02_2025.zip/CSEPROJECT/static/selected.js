//List to hold all of avalible CS classes being read in from slected_classes.html
let scheduledClasses = {};

// Add class to the schedule
function addClass(element) {
    let className = element.getAttribute('data-class');
    let days = element.getAttribute('data-days').split(',');
    let time = element.getAttribute('data-time');
    
    let conflict = false;

    // Check if the class time is already occupied
    for (let day of days) {
        if (scheduledClasses[`${day}-${time}`]) {
            conflict = true;
            break;
        }
    }

    // If there's a conflict, grey out the class and return
    if (conflict) {
        element.classList.add('disabled');
        return;
    }

    // Add class to the schedule
    for (let day of days) {
        let scheduleSlot = document.getElementById(`${day}-${time}`);
        if (scheduleSlot && scheduleSlot.textContent === "") {
            scheduleSlot.textContent = className;
            scheduleSlot.classList.add("scheduled-class");
            scheduleSlot.setAttribute("onclick", `removeClass('${className}', '${days.join(",")}', '${time}')`);
            scheduledClasses[`${day}-${time}`] = className;
        }
    }

    // Remove class from available list
    element.remove();
    updateAvailableClasses();
}

// Remove class from the schedule
function removeClass(className, days, time) {
    // Split days back into an array
    let daysArray = days.split(',');

    // Remove class from all scheduled time slots
    daysArray.forEach(day => {
        let scheduleSlot = document.getElementById(`${day}-${time}`);
        if (scheduleSlot && scheduleSlot.textContent === className) {
            scheduleSlot.textContent = "";
            scheduleSlot.classList.remove("scheduled-class");
            scheduleSlot.removeAttribute("onclick");
            delete scheduledClasses[`${day}-${time}`];
        }
    });

    // Add back the class to the available list only once
    let availableList = document.getElementById("available-list");
    let newItem = document.createElement("li");
    newItem.textContent = className;
    newItem.setAttribute("data-class", className);
    newItem.setAttribute("data-days", days);
    newItem.setAttribute("data-time", time);
    newItem.setAttribute("onclick", "addClass(this)");
    availableList.appendChild(newItem);

    // Update available classes
    updateAvailableClasses();
}

// Update available classes
function updateAvailableClasses() {
    let availableClasses = document.querySelectorAll('#available-list li');
    
    availableClasses.forEach((classItem) => {
        let days = classItem.getAttribute('data-days').split(',');
        let time = classItem.getAttribute('data-time');
        let conflict = false;
        
        for (let day of days) {
            if (scheduledClasses[`${day}-${time}`]) {
                conflict = true;
                break;
            }
        }
        
        if (conflict) {
            classItem.classList.add('disabled');
        } else {
            classItem.classList.remove('disabled');
        }
    });
}

// Initial call to update available classes status
updateAvailableClasses();
