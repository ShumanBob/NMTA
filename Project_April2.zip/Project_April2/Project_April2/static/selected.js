let scheduledClasses = {};

// Add class to the schedule
function addClass(element) {
    const className = element.getAttribute('data-class');
    const days = element.getAttribute('data-days').split(',');
    const time = element.getAttribute('data-time');

    // Check for conflicts
    const conflict = days.some(day => scheduledClasses[`${day}-${time}`]);
    if (conflict) {
        showConflictModal();
        return;
    }

    // Add the class to the schedule
    days.forEach(day => {
        const scheduleSlot = document.getElementById(`${day}-${time}`);
        if (scheduleSlot && scheduleSlot.textContent === "") {
            scheduleSlot.textContent = className;
            scheduleSlot.classList.add('scheduled-class'); // Apply the smaller text class
            scheduledClasses[`${day}-${time}`] = className;
        }
    });

    // Disable the class from the available list
    element.classList.add('disabled');
}

// Show conflict modal with a close button (X)
function showConflictModal() {
    const modal = document.createElement("div");
    modal.style.position = "fixed";
    modal.style.top = "50%";
    modal.style.left = "50%";
    modal.style.transform = "translate(-50%, -50%)";
    modal.style.padding = "20px";
    modal.style.backgroundColor = "white";
    modal.style.border = "1px solid black";
    modal.style.zIndex = "1000";

    // Close button (X)
    const closeButton = document.createElement("button");
    closeButton.textContent = "X";
    closeButton.style.position = "absolute";
    closeButton.style.top = "5px";
    closeButton.style.right = "10px";
    closeButton.style.fontSize = "16px";
    closeButton.style.cursor = "pointer";
    closeButton.style.backgroundColor = "transparent";
    closeButton.style.border = "none";
    closeButton.style.color = "black";
    closeButton.addEventListener("click", () => {
        document.body.removeChild(modal); // Remove modal when clicking X
    });

    const message = document.createElement("p");
    message.textContent = "You silly goose 🪿🔥🤪you already got a CLASS THEN big dawg😔🐕💯😔. If you wanna be silly, go here: ";
    
    const link = document.createElement("a");
    link.href = "https://www.youtube.com/watch?v=WM7WxhL0kSc";
    link.target = "_blank";
    link.textContent = "If you stwill wanna bwe silly cwick HERE >W<";

    // Append all elements to modal
    modal.appendChild(closeButton);
    modal.appendChild(message);
    modal.appendChild(link);

    // Append modal to the body
    document.body.appendChild(modal);
}

// Remove class from the schedule
function removeClass(element) {
    const className = element.textContent;

    if (className) {
        // Loop through all schedule slots and remove the class from all matching time slots
        Object.keys(scheduledClasses).forEach(slot => {
            if (scheduledClasses[slot] === className) {
                const [day, time] = slot.split('-');
                const scheduleSlot = document.getElementById(slot);
                if (scheduleSlot) {
                    scheduleSlot.textContent = "";
                    scheduleSlot.classList.remove('scheduled-class'); // Remove the smaller text class
                    delete scheduledClasses[slot];
                }
            }
        });
    }

    // Re-enable the class in the available list
    const classElements = document.querySelectorAll('li');
    classElements.forEach(classElement => {
        if (classElement.getAttribute('data-class') === className) {
            classElement.classList.remove('disabled');
        }
    });
}

// Filter available classes by department
function filterClasses() {
    const department = document.getElementById("department-select").value;
    const classList = document.querySelectorAll("#available-list li");
    
    classList.forEach(classItem => {
        const classDepartment = classItem.getAttribute('data-department');
        if (department === "all" || classDepartment === department) {
            classItem.style.display = "block";
        } else {
            classItem.style.display = "none";
        }
    });
}
