from flask import Flask, render_template, request, jsonify
import coursereader
import requests

app = Flask(__name__)
course_list = coursereader.main()

@app.route("/")
def home():
    return render_template("index.html", course_list=course_list)

@app.route("/computer_science", methods=["GET", "POST"])
def computer_science():
    if request.method == "POST":
        selected_classes = request.form.getlist("checkbox[]")
        return render_template("selected_classes.html", course_list=course_list)
    return render_template("computer_science.html")

@app.route("/mechanical_engineering")
def mechanical_engineering():
    return render_template("mechanical_engineering.html")

@app.route("/civil_engineering")
def civil_engineering():
    return render_template("civil_engineering.html")

@app.route("/electrical_engineering")
def electrical_engineering():
    return render_template("electrical_engineering.html")

@app.route("/biology")
def biology():
    return render_template("biology.html")

# Chat API endpoints

@app.route("/api/chat", methods=["GET"])
def api_chat_get():
    return jsonify({"message": "API is up"})

@app.route("/api/chat", methods=["POST"])
def api_chat_post():
    data = request.get_json()
    user_input = data.get("message", "")
    
    # build payload for Ollama chat API
    payload = {
        "model": "llama3.1:8b",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": user_input}
        ],
        "stream": False
    }
    
    api_url = "http://localhost:11434/api/chat"
    try:
        response = requests.post(api_url, json=payload)
        response.raise_for_status()
        result = response.json()
        assistant_reply = result.get("message", {}).get("content", "No response")
        return jsonify({"response": assistant_reply})
    except requests.exceptions.RequestException:
        return jsonify({"response": "Error communicating with the LLM."}), 500

if __name__ == "__main__":
    app.run(debug=True)
