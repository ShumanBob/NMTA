let scheduledClasses = {};
let totalCredits = 0; // initialize credit hour counter to 0

// Helper function to convert time (e.g., "9:00 AM") into a 24-hour format with minutes
function convertTimeToHour(timeString) {
    const [time, period] = timeString.split(" ");
    const [hour, minute] = time.split(":").map(Number);
    let convertedHour = hour;
    if (period === "PM" && hour !== 12) {
        convertedHour += 12;
    } else if (period === "AM" && hour === 12) {
        convertedHour = 0;
    }
    return { hour: convertedHour, minute };
}

// Parse the days string (e.g., "MWF", "TR", "F") into an array of days
function parseDays(days) {
    const dayMap = {
        M: "monday",
        T: "tuesday",
        W: "wednesday",
        R: "thursday",
        F: "friday"
    };
    const parsedDays = [];
    for (let i = 0; i < days.length; i++) {
        parsedDays.push(dayMap[days.charAt(i)]);
    }
    return parsedDays;
}

// Add class to the schedule
function addClass(element) {
    const className = element.getAttribute('data-class');
    const days = element.getAttribute('data-days');
    const time = element.getAttribute('data-time');
    const classDescription = element.getAttribute('data-title');
    let credits = element.getAttribute('data-credit_hours');


    // Parse the days and time into usable values
    const parsedDays = parseDays(days);
    const [startObj, endObj] = time.split(' - ').map(convertTimeToHour);
    const startTime = startObj.hour;
    const endTime = endObj.hour;

    // convert "variable" credit hours to 0
    const credit_hours = credits.toLowerCase() === "variable" ? 0 : parseInt(credits);

    // If end time is in the same hour but not at 00 minutes, include the last hour
    const includeLastHour = endObj.minute > 0;

    // Check if the class is already scheduled
    const isScheduled = Object.keys(scheduledClasses).some(slot => scheduledClasses[slot] === className);
    if (isScheduled) {
        removeClassFromSchedule(className, credit_hours);
        return;
    }

    // Check for conflicts
    let conflict = false;
    parsedDays.forEach(day => {
        for (let hour = startTime; hour < endTime; hour++) {
            const scheduleSlot = document.getElementById(`${day}-${hour}`);
            if (scheduleSlot && scheduleSlot.textContent !== "") {
                conflict = true;
                break;
            }
        }

        if (includeLastHour) {
            const scheduleSlot = document.getElementById(`${day}-${endTime}`);
            if (scheduleSlot && scheduleSlot.textContent !== "") {
                conflict = true;
            }
        }
    });

    if (conflict) {
        showConflictModal();
        return;
    }

    // Add class to schedule
    parsedDays.forEach(day => {
        for (let hour = startTime; hour < endTime; hour++) {
            const scheduleSlot = document.getElementById(`${day}-${hour}`);
            if (scheduleSlot && scheduleSlot.textContent === "") {
                scheduleSlot.textContent = classDescription;
                scheduleSlot.classList.add('scheduled-class');
                scheduledClasses[`${day}-${hour}`] = className;

                scheduleSlot.addEventListener("click", function () {
                    removeClassFromSchedule(className, credit_hours);
                });
            }
        }

        if (includeLastHour) {
            const scheduleSlot = document.getElementById(`${day}-${endTime}`);
            if (scheduleSlot && scheduleSlot.textContent === "") {
                scheduleSlot.textContent = classDescription;
                scheduleSlot.classList.add('scheduled-class');
                scheduledClasses[`${day}-${endTime}`] = className;

                scheduleSlot.addEventListener("click", function () {
                    removeClassFromSchedule(className, credit_hours);
                });
            }
        }
    });
    totalCredits += parseInt(credit_hours);
    updateCreditCounter();
}

// Remove class from the schedule
function removeClassFromSchedule(className, credit_hours) {
    let removed = false; // track if we actually removed something

    Object.keys(scheduledClasses).forEach(slot => {
        if (scheduledClasses[slot] === className) {
            const scheduleSlot = document.getElementById(slot);
            if (scheduleSlot) {
                scheduleSlot.textContent = "";
                scheduleSlot.classList.remove('scheduled-class');
                delete scheduledClasses[slot];
                removed = true;
            }
        }
    });

    if (removed) {
        totalCredits -= parseInt(credit_hours);
        if (totalCredits < 0) totalCredits = 0; // prevent negative values
        updateCreditCounter();
    }
}


// Show conflict modal with a close button
function showConflictModal() {
    const modal = document.createElement("div");
    modal.style.position = "fixed";
    modal.style.top = "50%";
    modal.style.left = "50%";
    modal.style.transform = "translate(-50%, -50%)";
    modal.style.padding = "20px";
    modal.style.backgroundColor = "#fff";
    modal.style.border = "2px solid #333";
    modal.style.borderRadius = "10px";
    modal.style.zIndex = "1000";
    modal.style.boxShadow = "0px 4px 10px rgba(0, 0, 0, 0.2)";

    const closeButton = document.createElement("button");
    closeButton.textContent = "X";
    closeButton.style.position = "absolute";
    closeButton.style.top = "5px";
    closeButton.style.right = "10px";
    closeButton.style.fontSize = "18px";
    closeButton.style.cursor = "pointer";
    closeButton.style.backgroundColor = "#ff4c4c";
    closeButton.style.border = "none";
    closeButton.style.color = "white";
    closeButton.style.borderRadius = "50%";
    closeButton.addEventListener("click", () => {
        document.body.removeChild(modal);
    });

    const message = document.createElement("p");
    message.textContent = "You already have a class scheduled at that time! Please choose a different slot.";
    message.style.fontSize = "16px";
    message.style.color = "#333";
    message.style.textAlign = "center";

    modal.appendChild(closeButton);
    modal.appendChild(message);
    document.body.appendChild(modal);
}

function updateCreditCounter() {
    const counter = document.getElementById("credit-counter");
    counter.textContent = `Credits: ${totalCredits}`;
}

