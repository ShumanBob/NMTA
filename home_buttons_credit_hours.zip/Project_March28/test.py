import pandas as pd
from datetime import datetime

# Convert military time (e.g., 1330.0) to 12-hour AM/PM format
def convert_time(military_time):
    if pd.isna(military_time):
        return ""
    time_str = f"{int(military_time):04d}"
    return datetime.strptime(time_str, "%H%M").strftime("%I:%M %p")  # Changed %-I to %I

# Load the CSV
df = pd.read_csv("coursesSp2024.csv")

# Collect formatted lines
formatted_classes = []

for _, row in df.iterrows():
    course_code = row['COURSE'].split('-')[0] if pd.notna(row['COURSE']) else ''
    dept = row['DEPT'] if pd.notna(row['DEPT']) else ''
    day1 = row['DAY1'] if pd.notna(row['DAY1']) else ''
    day2 = row['DAY2'] if pd.notna(row['DAY2']) else ''
    days = f"{day1}{day2}"
    begin = convert_time(row['BEGINTIME1'])
    end = convert_time(row['ENDTIME1'])
    time_range = f"{begin} - {end}" if begin and end else ''
    title = row['TITLE'] if pd.notna(row['TITLE']) else ''
    credit_hours = row['CREDS'] if pd.notna(row['CREDS']) else ''
    if not (course_code and dept and days and time_range and title):
        continue

    # Format output
    pretty_days = '/'.join(days)
    formatted_line = f"{course_code}, {dept}, {days}, {time_range}, {course_code} - {title} ({pretty_days} {time_range}), {credit_hours}"
    formatted_classes.append(formatted_line)

# Write to output file
with open("classes2.txt", "w") as f:
    for line in formatted_classes:
        f.write(line + "\n")

print("classes2.txt has been created.")
